import { Container } from "inversify";
import "reflect-metadata";
import { TYPES } from "./types";
import { ITaskService } from "./interfaces/ITaskService";
import { TaskService } from "./services/TaskServices";

const container = new Container();
container.bind<ITaskService>(TYPES.TaskService).to(TaskService).inSingletonScope();

export {container};
