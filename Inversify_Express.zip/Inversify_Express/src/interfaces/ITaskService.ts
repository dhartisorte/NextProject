import { Task } from "../models/Task";

export interface ITaskService {
    getAll(): Task[];
    getById(id: number) : Task | undefined;
    create(task: Task): Task;
    update(id: number , task: Task): Task | undefined;
    delete(id: number): boolean;
}