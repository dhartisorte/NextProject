import {injectable} from "inversify";
import { ITaskService } from "../interfaces/ITaskService";
import { Task } from "../models/Task";

@injectable()

export class TaskService implements ITaskService{
    private tasks: Task[] = [];
    private nextId = 1;

    getAll(): Task[] {
        return this.tasks;
    }

    getById(id: number): Task | undefined {
        return this.tasks.find(t => t.id === id);
    }

    create(task: Task) : Task{
        task.id = this.nextId++;
        this.tasks.push(task);
        return task;
    }

    update(id: number, task: Task): Task | undefined {
        const index = this.tasks.findIndex(t => t.id === id);
        if(index === -1) return undefined;
        this.tasks[index] = {...task , id};
        return this.tasks[index];
    }

    delete(id: number): boolean {
        const index = this.tasks.findIndex(t => t.id === id);
        if(index === -1) return false;
        this.tasks.splice(index , 1);
        return true;
    }
}