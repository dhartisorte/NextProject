import {container} from "./inversify.config";
import { TaskController } from "./controllers/TaskController";
import { TYPES } from "./types";
import express from "express";

import "reflect-metadata"
import bodyParser from "body-parser";

const app = express();
const port = 3000;

app.use(express.json());

const taskController = new TaskController(container.get(TYPES.TaskService));
app.use("/tasks" , taskController.router);

app.listen(port , () => {
    console.log(`Server running at http://localhost:${port}`);
});