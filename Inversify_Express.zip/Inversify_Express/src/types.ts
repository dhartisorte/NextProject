export const TYPES = {
    TaskService: Symbol.for("TaskServices"),
};