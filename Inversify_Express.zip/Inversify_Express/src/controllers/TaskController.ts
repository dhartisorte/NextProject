import express , {Request , Response} from "express";
import { inject , injectable } from "inversify";
import { ITaskService } from "../interfaces/ITaskService";
import { TYPES } from "../types";

@injectable()

export class TaskController {
    public router = express.Router();

    constructor(
        @inject(TYPES.TaskService) private taskService: ITaskService
    ){
        this.router.get("/" , this.getAll);
        this.router.get("/:id" , this.getById);
        this.router.post("/" , this.create);
        this.router.put("/:id" , this.update);
        this.router.delete("/" , this.delete);
    }

    getAll = (req: Request , res: Response) => {
        res.json(this.taskService.getAll());
    };

    getById = (req: Request , res: Response) => {
        const id = parseInt(req.params.id);
        const task = this.taskService.getById(id);
        if(!task) return res.status(404).send("Not Found");
        res.json(task);
    };

    create = (req: Request , res : Response) => {
        const task = this.taskService.create(req.body);
        res.status(201).json(task);
    };

    update = (req: Request , res : Response) => {
        const id = parseInt(req.params.id);
        const task = this.taskService.update(id , req.body);
        if(!task) return res.status(404).send("Not found");
        res.json(task);
    };

    delete = (req: Request , res : Response) => {
        const id = parseInt(req.params.id);
        const success = this.taskService.delete(id);
        if(!success) return res.status(404).send("Not found");
        res.sendStatus(204);
    };
}